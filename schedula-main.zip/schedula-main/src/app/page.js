export default function Home() {
  return (
    <main className="flex items-center justify-center h-screen bg-white">
      <h1 className="text-4xl font-bold text-black">Welcome to Schedula suiiii im him 🚀</h1>
    </main>
  );
}
